import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import java.io.File;

public class PostMultipartExample {
    public static void main(String[] args) {
        String url = "https://example.com/process";

        // Create HTTP client
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            // Create POST request
            HttpPost uploadFile = new HttpPost(url);

            // Build multipart entity
            MultipartEntityBuilder builder = MultipartEntityBuilder.create();
            builder.addTextBody("id", "123", ContentType.TEXT_PLAIN);
            builder.addTextBody("name", "John Doe", ContentType.TEXT_PLAIN);
            builder.addTextBody("age", "28", ContentType.TEXT_PLAIN);

            // Attach files
            builder.addBinaryBody("cv", new File("resume.pdf"), ContentType.APPLICATION_OCTET_STREAM, "resume.pdf");
            builder.addBinaryBody("photo", new File("profile.jpg"), ContentType.APPLICATION_OCTET_STREAM, "profile.jpg");

            HttpEntity multipart = builder.build();
            uploadFile.setEntity(multipart);

            // Execute request
            try (CloseableHttpResponse response = httpClient.execute(uploadFile)) {
                HttpEntity responseEntity = response.getEntity();
                System.out.println("Status Code: " + response.getStatusLine().getStatusCode());
                if (responseEntity != null) {
                    String responseString = EntityUtils.toString(responseEntity);
                    System.out.println("Response: " + responseString);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
