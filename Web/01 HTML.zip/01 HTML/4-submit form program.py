import requests

# Target URL
url = "https://example.com/process"

# Text / integer data
data = {
    "id": 123,
    "name": "John Doe",
    "age": 28
}

# Files to upload (open in binary mode)
files = {
    "cv": open("resume.pdf", "rb"),
    "photo": open("profile.jpg", "rb")
}

# Send POST request
response = requests.post(url, data=data, files=files)

# Print response from server
print("Status Code:", response.status_code)
print("Response Text:", response.text)

# Close files after upload
files["cv"].close()
files["photo"].close()
